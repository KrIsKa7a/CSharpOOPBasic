﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03.WildFarm.Models.Food
{
    public class Meat : Food
    {
        public Meat(int quantity) : base(quantity)
        {
        }
    }
}
