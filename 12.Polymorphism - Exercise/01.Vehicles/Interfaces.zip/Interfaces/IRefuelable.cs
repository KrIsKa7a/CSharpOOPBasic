﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01.Vehicles.Interfaces
{
    public interface IRefuelable
    {
        void Refuel(double liters);
    }
}
