﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IDriveable
{
    string UseBrakes();
    string PushGasPedal();
}
