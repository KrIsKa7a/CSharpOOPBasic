﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IBirthdate
{
    DateTime BirthDate { get; }
}
